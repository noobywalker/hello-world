//
//  SPFIRHelper.h
//  FirebaseHelper
//
//  Created by M Waratnan on 11/2/16.
//  Copyright © 2016 M Waratnan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPFIRHelper : NSObject
-(void)configure;
-(void)tokenRefreshNotificaion:(NSNotification *)notificaiton;
-(void)connectToFCM;
-(void)disconnectFromFCM;
@end
