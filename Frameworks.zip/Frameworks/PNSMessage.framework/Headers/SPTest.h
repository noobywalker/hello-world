//
//  SPTest.h
//  FirebaseHelper
//
//  Created by M Waratnan on 11/2/16.
//  Copyright © 2016 M Waratnan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPTest : NSObject
-(void)spTestLog;

@end
